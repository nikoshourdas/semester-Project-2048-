package model;
import View.Observer;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Board implements Observable {
    private int[][] board;
    private int score;
    private List<Observer> observers;
    private boolean isGameOver;
    static int last;
    static int kap;
    public Board(int[][] board) {
        last=0;
        observers = new ArrayList<>();
        this.board = board;
        this.score = 0;
        isGameOver = false;
        generateNewNumber(board[0].length, board);
    }

    public int[][] getBoard() {
        return board;
    }



    // elexos olwn ton kinhsewm 31-128 gia thn anazhthsh  kinhshs mesw mia for pou vlepei olo to board kai  an yparxei stelnei true
    public void handleSwipeUp() {
        boolean hasBoardChanged = false;
        boolean temp;
        for (int i = 0; i < board.length - 1; i++) {
            for (int j = 0; j < board[0].length; j++) {
                temp = handleNorthBlock(board[0].length - 1 - i, j);
//                System.out.println(temp);
//                 System.out.println("1");
                if (temp) {
                    kap=0;
                    hasBoardChanged = true;
                }
            }
        }
        if (hasBoardChanged && !isGameOver(board)) {
            generateNewNumber(board[0].length, board);
        } else if (!hasBoardChanged) {
            isGameOver = isGameOver(board);
        }
        updateAllObservers();
    }

    public void handleSwipeRight() {
        boolean hasBoardChanged = false;
        boolean temp;
        for (int i = 0; i < board.length - 1; i++) {
            for (int j = 0; j < board[0].length; j++) {
                temp = handleEastBlock(j, i);
//                System.out.println(temp);
//                 System.out.println("2");

                if (temp) {
                    kap=0;
                    hasBoardChanged = true;
                }
            }
        }
        if (hasBoardChanged && !isGameOver(board)) {
            generateNewNumber(board[0].length, board);
        } else if (!hasBoardChanged) {
            isGameOver = isGameOver(board);
        }
        updateAllObservers();
    }


    public void handleSwipeLeft() {
        boolean hasBoardChanged = false;
        boolean temp;

        for (int i = 0; i < board.length - 1; i++) {

            for (int j = 0; j < board[0].length; j++) {
                temp = handleWestBlock(j, board.length - i - 1);
//                System.out.println(temp);
//                 System.out.println("3");
                if (temp) {
                    kap=0;
                    hasBoardChanged = true;
                }
            }
        }
        if (hasBoardChanged && !isGameOver(board)) {
            generateNewNumber(board[0].length, board);
        } else if (!hasBoardChanged) {
            isGameOver = isGameOver(board);
        }
        updateAllObservers();
    }

    public void handleSwipeDown() {
        boolean hasBoardChanged = false;
        boolean temp;

        for (int i = 0; i < board.length - 1; i++) {

            for (int j = 0; j < board[0].length; j++) {
                temp = handleSouthBlock(i, j);
//                  System.out.println(temp);
//                   System.out.println("4");
                if (temp) {
                    kap=0;
                    hasBoardChanged = true;
                }
            }
        }
        if (hasBoardChanged && !isGameOver(board)) {
            generateNewNumber(board[0].length, board);
        } else if (!hasBoardChanged) {
            //elexos tou gameover gia na synexisei h na bgalei to gameover panel
            isGameOver = isGameOver(board);
        }
        updateAllObservers();
    }

    public boolean isGameOver() {
        return isGameOver;
    }

    private boolean handleNorthBlock(int yCoord, int xCoord) {
        //kinhsh  kai elexos se block +1 gia thn  topothethsei tou kainourgiou sto  askona x-1
        if (board[yCoord][xCoord] == board[yCoord - 1][xCoord] || board[yCoord - 1][xCoord] == 0) {
            if(kap==0){
                kap=1;
                board[yCoord - 1][xCoord] = board[yCoord][xCoord] + board[yCoord - 1][xCoord];
                board[yCoord][xCoord] = 0;


                score += board[yCoord - 1][xCoord];
                return true;
            }
        }
        return false;
    }

    private boolean handleSouthBlock(int yCoord, int xCoord) {
        //kinhsh  kai elexos se block +1 gia thn  topothethsei tou kainourgiou sto  askona x+1
        if (board[yCoord][xCoord] == board[yCoord + 1][xCoord] || board[yCoord + 1][xCoord] == 0) {

            if(kap==0){
                board[yCoord + 1][xCoord] = board[yCoord][xCoord] + board[yCoord + 1][xCoord];
                board[yCoord][xCoord] = 0;
                score += board[yCoord + 1][xCoord];
                kap=1;
                return true;
            }
        }
        return false;
    }

    private boolean handleWestBlock(int yCoord, int xCoord) {
        //kinhsh  kai elexos se block +1 gia thn  topothethsei tou kainourgiou sto  askona y-1
        if (board[yCoord][xCoord] == board[yCoord][xCoord - 1] || board[yCoord][xCoord - 1] == 0 ) {

            if(kap==0){
                board[yCoord][xCoord - 1] = board[yCoord][xCoord] + board[yCoord][xCoord - 1];
                board[yCoord][xCoord] = 0;
                score += board[yCoord][xCoord - 1];
                kap=1;
                return true;
            }
        }
        return false;
    }

    private boolean handleEastBlock(int yCoord, int xCoord) {
        //kinhsh  kai elexos se block +1 gia thn  topothethsei tou kainourgiou sto  askona y+1
        if (board[yCoord][xCoord] == board[yCoord][xCoord + 1] || board[yCoord][xCoord + 1] == 0) {
            if(kap==0){
                kap=1;//peritos elexos flag apla thelame na diorthwsoume ena bug
                board[yCoord][xCoord + 1] = board[yCoord][xCoord] + board[yCoord][xCoord + 1];
                board[yCoord][xCoord] = 0;
                score += board[yCoord][xCoord + 1];
                return true;
            }
        }
        return false;
    }
    //check gia gameover
    private static boolean isGameOver(int[][] board) {
        for (int i = 0; i < board[0].length; i++) {
            for (int j = 0; j < board[0].length; j++) {
                if (board[i][j] < 2) {
                    return false;
                }
            }
        }
        return true;
    }


    private static void generateNewNumber(int length, int[][] board) {
        Random random = new Random();
        Random random1 = new Random();
        int xAxis, yAxis,yAxis1;
        //dhmiourgia neou arithmou

        do {
            int min = 1;
            int max = 10;
            int value = random1.nextInt(max + min) + min;
            xAxis = Math.abs(random.nextInt()) % length;
            yAxis = Math.abs(random.nextInt()) % length;
            yAxis1 = Math.abs(random.nextInt()) % length;
            do{
                //dhmiourgia  mono thn prwth fora 2 arithmous
                if(yAxis==yAxis1){
                    yAxis1 = Math.abs(random.nextInt()) % length;
                }
                else{
                    break;
                }
            }while(true);
            //elenxos prwta gia thn topothethsei
            if (!isOccupied(yAxis, xAxis, board)) {
                if(value==10){
                    board[yAxis][xAxis] = 4;
                }
                else{
                    board[yAxis][xAxis] = 2;
                }
                if(yAxis1!=yAxis && last ==0){
                    board[yAxis1][xAxis] = 2;
                    last = 1;
                    break;
                }
                break;
            }
        } while (true);
    }

    private static boolean isOccupied(int yAxis, int xAxis, int[][] board) {
        if (board[yAxis][xAxis] < 2) {
            //check  an  to block einai appasxolhmeno  dhladh an exei arithmo megalytero tou 2
            return false;
        }
        return true;
    }

    public int getScore() {
        return score;
    }

    @Override
    public void addObserver(Observer observer) {
        observers.add(observer);
        //add observer
    }

    @Override
    public void updateAllObservers() {
        //update ta observers
        observers.stream().forEach(x -> {
            try {
                x.update(this);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }
}