package model;

import View.Observer;

public interface Observable {
    void addObserver(Observer observer);

    void updateAllObservers();
}
