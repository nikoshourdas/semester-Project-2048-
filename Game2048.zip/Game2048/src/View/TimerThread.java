package View;

import javafx.scene.control.Label;

import java.awt.*;
import java.util.Timer;
import java.util.TimerTask;

//creates a thread that runs simutaniously with the main thread
//uses singleton pattern and a mutex lock to avoid any mistakes when counting the time

public class TimerThread  extends  Thread{

    private static volatile TimerThread singletonThread ; //volatile guarantees visibility of changes to variables across threads.
    private  static Object mutex = new Object();

    int secondsPassed = 0 ;      //counter used for calculating the seconds spent in game

    private TimerThread(){      //avoids any new object creeation with the 'new' operator
        Timer myTimer = new Timer();
            TimerTask task = new TimerTask() {
                @Override
                public void run() {
                    secondsPassed++;
                    //debugging tool - prints the counter on the terminal

                    //System.out.println("seconds Passed : " + secondsPassed);
                }
            };
            myTimer.scheduleAtFixedRate(task,1000,1000);
    }

    //return the single instance of this class

    public static TimerThread getInstance(){
        TimerThread result = singletonThread;
        if(result == null){
            synchronized (mutex){
                result = singletonThread;
                if(result == null) singletonThread = result = new TimerThread();

            }
        }

        return singletonThread;
    }

    public int getSecondsPassed() {
        return secondsPassed;
    }

}

