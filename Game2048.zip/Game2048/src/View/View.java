package View;
import controller.Controller;
import controller.HIghtscoresMenu;
import controller.MainMenu;
import controller.SingletonDatabase;
import java.awt.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import model.Board;
import model.Observable;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.scene.image.ImageView;
import javafx.stage.WindowEvent;

public class View implements Observer {
    private Group root;
    private Scene scene;
    private GridPane boardGame;
    private Button startnew,restartgame;
    private MainMenu mScene;
    private Stage primaryStage;
    private boolean flag;
    private  String name;
    static int  flag1;
    private int score;
    public int timer2;
    public   TimerThread myThread = TimerThread.getInstance();
    HIghtscoresMenu HSScene = new HIghtscoresMenu();

    public View(Group root, Scene scene,MainMenu mScene,Stage primaryStage,String name) {
        this.root = root;
        this.name=name;
        this.scene = scene;
        this.mScene = mScene;
        this.primaryStage = primaryStage;
        this.boardGame = new GridPane();
        root.getChildren().add(boardGame);
        boardGame.setPadding(new Insets(100));
        boardGame.setHgap(20);
        boardGame.setVgap(20);
        flag1=0;
        int time = TimerThread.getInstance().secondsPassed = 0 ;
    }

    public void drawBoard(Board board) {
        //sxediasmos board     //dhmiourgia menubar kai items
        Menu options = new Menu("Game");
        MenuBar menuBar = new MenuBar();
        ImageView imgView1 = new ImageView("View/clock.png");
        imgView1.setFitWidth(20);
        imgView1.setFitHeight(20);
        Menu timer = new Menu("Timer",imgView1);
        Menu about = new Menu("About");
        Menu history = new Menu("History");
        MenuItem help = new MenuItem("Help");
        MenuItem showhistory = new MenuItem("Show History");
        MenuItem hidehistory = new MenuItem("Hide History");
        MenuItem startnew = new MenuItem("Start New Game");
        MenuItem restart = new MenuItem("Restart Game");
        MenuItem exit = new MenuItem("Exit");
        options.getItems().add(startnew);
        options.getItems().add(restart);
        options.getItems().add(exit);
        menuBar.getMenus().add(options);
        menuBar.getMenus().add(about);
        menuBar.getMenus().add(history);
        menuBar.getMenus().add(timer);
        about.getItems().add(help);
        history.getItems().add(showhistory);
        history.getItems().add(hidehistory);
        root.getChildren().add(menuBar);
        primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent t) {
                Platform.exit();
                System.exit(0);
            }
        });
        //dhmiourgia restart ,new game kai  exit
        startnew.setOnAction(e -> {
            Dimension c= Toolkit.getDefaultToolkit().getScreenSize();
            primaryStage.show();
            primaryStage.setX(c.width/1.5-(primaryStage.getWidth()/1.5));
            primaryStage.setY(c.height/1.5-(primaryStage.getHeight()/2.5));
            primaryStage.setScene(mScene.getMainMenu());
        });
        restart.setOnAction(e -> {
            Controller controller = new Controller(root,scene,mScene,primaryStage,name);
            int time = TimerThread.getInstance().secondsPassed = 0 ;
        });
        exit.setOnAction(e -> {
            Platform.exit();
            System.exit(0);
        });

        showhistory.setOnAction(e -> {
            StackPane secondaryLayout = new StackPane();
            Scene secondScene = new Scene(secondaryLayout, 650, 180);
            Stage secondStage = new Stage();
            secondStage.setScene(HSScene.getHsMenu());
            secondStage.setTitle("History");
            secondStage.show();

            HSScene.goBack.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent mouseEvent) {
                    secondStage.close();
                }
            });
            hidehistory.setOnAction(b -> {
                secondStage.close();

            });

        });
        help.setOnAction(e -> {
            Label secondLabel = new Label("2048 game is a single-player sliding tile puzzle video game written by Italian web \n " +
                    " developer Gabriele Cirulli and published on GitHub.A gameJoin the tiles, get to 2048!\n  How to play:" +
                    " Use your arrow keysSwipe with your fingers to move the tiles.\n " +
                    "Tiles with the same number merge into one when they touch. \n Add them up to reach 2048! ");
            secondLabel.setFont(Font.font("Arial Black", 13));
            Button b = new Button("                            OK                               ");
            StackPane secondaryLayout = new StackPane();
            VBox root1 = new VBox();
            root1.getChildren().add(b);
            root1.setAlignment(Pos.BOTTOM_CENTER);
            VBox.setMargin(b, new Insets(10, 10, 10, 10));
            secondaryLayout.getChildren().addAll(secondLabel,root1);
            Scene secondScene = new Scene(secondaryLayout, 650, 200);
            Stage secondStage = new Stage();
            secondStage.setTitle("Help");
            secondStage.setScene(secondScene);
            //Set position of second window, related to primary window.
            secondStage.setX(primaryStage.getX() + 250);
            secondStage.setY(primaryStage.getY() + 400);
            b.setOnAction(es -> {
                secondStage.close();
            });
            secondStage.show();
        });
        //dhmiourgia board  ews to mhkos tou
        for (int j = 0; j < board.getBoard().length; j++) {
            for (int i = 0; i < board.getBoard()[0].length; i++) {
                StackPane stack = new StackPane();
                Rectangle cell = new Rectangle(120, 120, Color.rgb(40, board.getBoard()[i][j] % 30 + 176, 190 - board.getBoard()[i][j] % 100)); //colors sta cells
                cell.setStroke(Color.WHITE);//xrwma pisw apo ta cells dhladh ta koutakia
                cell.setArcHeight(20);//ypsos ktlp
                cell.setArcWidth(20);
                Label label = new Label(" ");
                label.setScaleX(2.0);
                label.setScaleY(2.0);
                label.setFont(Font.font("Arial Black", 15));
                if (board.getBoard()[i][j] != 0) {
                    label.setText(String.valueOf(board.getBoard()[i][j]));
                }
                stack.getChildren().addAll(cell, label);
                boardGame.add(stack, j, i, 1, 1);
            }
            Label label = new Label("Score :   " + board.getScore());//pairnoume to score apo to board kai to grafoume panw apo to board
            label.setStyle("-fx-background-color: cyan;-fx-text-fill: Black");
            label.setFont(Font.font("Arial Black", 35));
            label.setLayoutX(350);
            label.setLayoutY(25);
            root.getChildren().add(label);
        }
        //thread of timer creation
        Timer timerA = new Timer();
        timerA.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        timer.setText("Timer:"+myThread.getSecondsPassed());
                    }
                });
            }
        }, 0, 1000);  }
    @Override
    public void update(Observable changedObservable) throws IOException {
        drawBoard((Board) changedObservable);//to observbable frame to elenxei kathe fora sthn klassh board gia to state gameover to opoio einai ena flag
        if (((Board) changedObservable).isGameOver()) {
            System.out.println("Game Over");
            score = ((Board) changedObservable).getScore();
            System.out.println(((Board) changedObservable).getScore());
            root.getChildren().clear();
            VBox vBox = new VBox();
            Text gameOver = new Text("Game Over \nYou scored: ");
            gameOver.setFont(Font.font("Arial Black", 30));
            Text scoreText = new Text(String.valueOf(score));
            Text pointstext = new Text("\nPoints!! ");
            pointstext.setFont(Font.font("Arial Black", 30));
            scoreText.setFont(Font.font("Arial Black", 35));
            //dhmiourgia panel tou gameover
            Button tryagain;
            tryagain = new Button();
            tryagain.setStyle("-fx-border-color: lightblue; -fx-border-width: 2px;");
            tryagain.setText("   Try Again!  ");
            vBox.getChildren().addAll(gameOver,scoreText,pointstext,tryagain);
            root.getChildren().add(vBox);
            vBox.setAlignment(Pos.CENTER);
            vBox.setPadding(new Insets(360));
            flag1=1;
            if(flag1==1){
                //otan ftasaei sto gameover pairnei to final timer kai to stelnei sthn  bash
                timer2=myThread.getSecondsPassed();
                //System.out.println(timer2);
            }
            //apostolh dedomenwn sth bash
            SingletonDatabase sql=SingletonDatabase.getInstance();
            sql.initsql(name,score,timer2);
            //try_again button  ton petaei sto menu gia na ksanabalei - ksanapaiksei
            tryagain.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent mouseEvent) {
                    Dimension c= Toolkit.getDefaultToolkit().getScreenSize();
                    primaryStage.show();
                    primaryStage.setX(c.width/1.5-(primaryStage.getWidth()/1.5));
                    primaryStage.setY(c.height/1.5-(primaryStage.getHeight()/2.5));
                    primaryStage.setScene(mScene.getMainMenu());
                    primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
                        @Override
                        public void handle(WindowEvent t) {
                            Platform.exit();                    //exit
                            System.exit(0);
                        }
                    });
                }
            });
        }
    }
}