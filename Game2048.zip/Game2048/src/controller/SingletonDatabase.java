package controller;

import java.sql.*;

public class SingletonDatabase {

    static Connection con =  null;
    private String name;

    static SingletonDatabase instance=null;
    public int timer2,score;

    public SingletonDatabase(){

    }
    //Singleton_DataBase
    public void initsql(String name,int score,int timer2){
        this.name=name;
        this.score=score;
        try{
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/2048?verifyServerCertificate=false&useSSL=true","root","1234");//dhmiourgia syndeshs sthn bash
            Statement stmt=con.createStatement();
            String query = "insert into 2048_table" + "(names,score,timer)" + "values(?,?,?)";
            PreparedStatement preparedStmt = con.prepareStatement(query);
            preparedStmt.setString(1, name);
            preparedStmt.setInt(2, score);
            preparedStmt.setInt(3, timer2);//insert values

            preparedStmt.executeUpdate();
            con.close();
        }
        catch(Exception e){ System.out.println(e);}
    }

    public String[] getData() throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException{
        String[] scores = new String[10];
        try{
            Class.forName("com.mysql.jdbc.Driver").newInstance();       //syndesh gia thn anazhthsh timwn
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/2048?verifyServerCertificate=false&useSSL=true","root","1234");
            Statement st = con.createStatement();
            String sql = ("SELECT * FROM 2048_table ORDER BY score DESC;");     //euresh kai taksinomhsh
            ResultSet rs = st.executeQuery(sql);
            for(int i=0;i<10;i++){      //elegxei tous 10 top scorers
                if(rs.next()){
                    String name = rs.getString("names");
                    int score = rs.getInt("score");
                    int timer = rs.getInt("timer");         //vazei ta values kai tha ta stelnei sthn Highscores
                    scores[i]=(name + "  " + String.valueOf(score) +" "+  timer );
                }}
            con.close();
        }
        catch(Exception e){ System.out.println(e);}
        return scores;
    }

    static public SingletonDatabase getInstance(){
        if(instance==null){
            instance=new SingletonDatabase();
        }
        return instance;
    }
}

