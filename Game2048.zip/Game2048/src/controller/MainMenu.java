package controller;

import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;

public class MainMenu {
    Scene mainMenu ;
    GridPane gridLayout , buttonGrid ;
    Label homePageLabel , homePageFooter ;
    Button startButton ,startButton1,
            namebutton,
            highScoreButton,
            difficultyButton,
            nameButton,
            ExitButton,
            testButotn;
    MainMenu (){
        homePageLabel = new Label(" 2048");
        homePageLabel.setFont(new Font(50));
        homePageFooter = new Label("2048 the game - Winter Semester 2021 -Javafx  Team <3");

//this buttons initializes the main game
        startButton = new Button();
        startButton.setStyle("-fx-text-fill: #5F9EA0  ");
        startButton.setText("   Start Game  ");
        startButton.prefWidth(90);
        startButton.prefHeight(90);

        startButton1 = new Button();
        startButton1.setStyle("-fx-text-fill: #5F9EA0  ");
        startButton1.setText("   Start1 Game  ");
        startButton1.prefWidth(90);
        startButton1.prefHeight(90);

//this buttons give the ability to set your name
        nameButton = new Button();


//connect to the data base and displays the top 10 scores achieved
        highScoreButton = new Button();
        highScoreButton.setStyle("-fx-text-fill: #5F9EA0  ");
        highScoreButton.setText("   Highscore  ");
        highScoreButton.prefWidth(90);
        highScoreButton.prefHeight(90);

//chooses between 3 difficulties - easy - normal - hard
        difficultyButton = new Button();
        difficultyButton.setStyle("-fx-text-fill: #5F9EA0  ");
        difficultyButton.setText("    Difficulty     ");
        difficultyButton.prefWidth(90);



        testButotn = new Button();

//closesdifficultyButton.setText("    Di all scenes and windows created and terminates programm
        difficultyButton.prefWidth(90); ExitButton = new Button();

        ExitButton.setStyle("-fx-text-fill : #5F9EA0  ");
        ExitButton.prefWidth(200);
        ExitButton.prefHeight(48);
        ExitButton.setText("         Exit        ");
        ExitButton.setOnAction(actionEvent -> Platform.exit());
//remove
        buttonGrid = new GridPane();
        buttonGrid.add(startButton,0,1);
        // buttonGrid.add(nameButton,0,2);
        buttonGrid.add(highScoreButton,0,3);
        buttonGrid.add(difficultyButton,0,2);
        buttonGrid.add(ExitButton,0,4);
        buttonGrid.add(testButotn,0,5)            ;
        buttonGrid.setAlignment(Pos.CENTER);
        buttonGrid.setHgap(10);
        buttonGrid.setVgap(10);
        buttonGrid.setPadding(new Insets(10,10,10,10));
        gridLayout = new GridPane();
        homePageLabel.setAlignment(Pos.CENTER);
        gridLayout.add(homePageLabel,0,1);
        gridLayout.add(buttonGrid,0,2);
        gridLayout.add(homePageFooter,0,3);
        gridLayout.setAlignment(Pos.CENTER);
        gridLayout.setPadding(new Insets(10,10,10,10));
        ColumnConstraints col1 = new ColumnConstraints();
//col1.setPercentWidth(50);
        col1.setFillWidth(true);
        gridLayout.getColumnConstraints().add(col1);
        mainMenu = new Scene(gridLayout,500,500);

    }

    public Scene getMainMenu() {
        return mainMenu;
    }
}
