
package controller;


import javafx.scene.control.TextField;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.control.Label;
import javafx.scene.control.Button;

//opens this windows after pressing the 'start game ' button
//it allows you to type in your name so it may be reccorder in the database after you finsih the game

public class NameC {
    
    Scene NameMenu;
    Button start ,back;
    TextField textField;
    GridPane gridPane ;

    NameC(){
        start = new Button("Go!");
        start.setStyle("-fx-text-fill: #5F9EA0  ");
        start.setPrefSize(200,30);
        
        back = new Button("Back");
        back.setStyle("-fx-text-fill: #5F9EA0  ");
        back.setPrefSize(200,30);
        gridPane = new GridPane();
        
        textField = new TextField ();
        textField.setFocusTraversable(false); 
        textField.setPromptText("Enter your  name.");  //input for name
        GridPane.setConstraints(textField, 0, 0);
        
        gridPane.getChildren().add(textField);
        NameMenu = new Scene(gridPane,500,500);
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setVgap(5);
        gridPane.add(start,0,1);
        gridPane.add(back,0,2);
    }
    
    public void setName(){
        this.textField.setText(textField.getText());
    }
    
    public String getName(){
        return this.textField.getText();
    }
    
    public Scene getNameMenu() {
        return NameMenu;
    }
}
