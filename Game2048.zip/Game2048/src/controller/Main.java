package controller;


import java.awt.Dimension;
import java.awt.Toolkit;
import javafx.scene.Group;
import java.io.IOException;
import javafx.scene.paint.Color;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

//bibliothikes

public class Main extends Application {
    MainMenu mScene = new MainMenu();
    HIghtscoresMenu HSScene = new HIghtscoresMenu();
    DifficultyMenu dScene = new DifficultyMenu();
    NameC NameButton = new NameC();
    testEksetashs exam = new testEksetashs();
    String name;
    //dhmiourgia menu-scenes

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws IOException {


        primaryStage.setTitle("2048");
        Dimension c= Toolkit.getDefaultToolkit().getScreenSize();
        primaryStage.show();
        primaryStage.setX(c.width/1.3-(primaryStage.getWidth()/1.6));
        primaryStage.setY(c.height/1.3-(primaryStage.getHeight()/1.4));
        primaryStage.setScene(mScene.getMainMenu());
        //arxiko menu

        mScene.startButton.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                primaryStage.setScene(NameButton.getNameMenu());//bazei to  menu gia to onoma gia na arxisei to paixnidi


            }
        });

        NameButton.start.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                //dhmiourgia game

                Dimension d= Toolkit.getDefaultToolkit().getScreenSize();
                Group root = new Group();
                Scene scene = new Scene(root,950,950,Color.LIGHTBLUE);
                primaryStage.setX(d.width/2.9-(primaryStage.getWidth()/2.5));
                primaryStage.setY(d.height/2.5-(primaryStage.getHeight()/1.5));
                primaryStage.setScene(scene);
                primaryStage.setTitle("2048");
                primaryStage.show();
                NameButton.setName();
                name=NameButton.getName();
                Controller controller = new Controller(root,scene,mScene,primaryStage,name);


            }
        });

        NameButton.back.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                primaryStage.setScene(mScene.getMainMenu());        //back button gia menu


            }
        });

        mScene.highScoreButton.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                primaryStage.setScene(HSScene.getHsMenu());     //highscore menu

            }
        });

        HSScene.goBack.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                primaryStage.setScene(mScene.getMainMenu());  //back to menu

            }
        });

        mScene.difficultyButton.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                primaryStage.setScene(dScene.getdMenu()); //difficult menu

            }
        });

        dScene.goBack.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                primaryStage.setScene(mScene.getMainMenu());    //back to menu

            }

        });

        mScene.testButotn.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                primaryStage.setScene(exam.getExamScene());
            }
        });

        primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent t) {
                Platform.exit();
                System.exit(0);     //stop everything including threads and exit the game.
            }
        });
    }


}
