package controller;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.control.Label;
import javafx.scene.control.Button;


public class DifficultyMenu {
    static  int x=4; //default size/difficulty of the game is normal or a 4x4 board
    Scene dMenu ;
    Button easy,normal,hard,extrahard;
    Button goBack ;
    Label label;
    GridPane gridPane;

    DifficultyMenu(){
        label = new Label("Choose Difficulty : ");
        easy = new Button("Easy");
        easy.setStyle("-fx-text-fill: #5F9EA0  ");
        normal = new Button("Normal");
        normal.setStyle("-fx-text-fill: #5F9EA0  ");
        hard = new Button("Hard");
        hard.setStyle("-fx-text-fill: #5F9EA0  ");

        extrahard = new Button("NIGHTMARE!");
        extrahard.setStyle("-fx-text-fill: #5F9EA0  ");


        goBack = new Button("Go Back");
        goBack.setStyle("-fx-text-fill: #5F9EA0  ");
        goBack.setPrefSize(200,30);
        gridPane = new GridPane();

        dMenu = new Scene(gridPane,500,500);
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setVgap(10);
        gridPane.add(label,0,0);
        gridPane.add(easy,0,1);
        gridPane.add(normal,0,2);
        gridPane.add(hard,0,3);
        gridPane.add(extrahard,0,4);
        gridPane.add(goBack,0,5);



        easy.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                x =5; // creates a 5x5 board
                System.out.println(x); 
            }
        });
        normal.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                 x=4; //creates a 4x4 board
                 System.out.println(x);
            }
        });
        hard.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                 x=3; //creats a 3x3 board
                 System.out.println(x);
            }
        });
        extrahard.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                x = 2;
                System.out.println(x);
            }
        });
    }

    public Scene getdMenu() {
        return dMenu;
    }

    public static class getX {

        public int getX() {
            return x;
        }
    }
}
