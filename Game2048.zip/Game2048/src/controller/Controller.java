package controller;

import View.View;
import static controller.DifficultyMenu.x;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import model.Board;
import java.io.IOException;
import java.util.Arrays;
import javafx.application.Platform;
import javafx.stage.Stage;



public class Controller {
    private Board board;
    private View view;
    private KeyCode keyPressed;


    public Controller(Group root, Scene scene,MainMenu mScene,Stage primaryStage,String name) {
        int[][] myBoard = new int[x][x];    //set board analogws me thn dyskolia
        this.view = new View(root, scene,mScene,primaryStage,name);     //pairnei metablhtes scenes kai ta stelnei sto view

        //dhmiourgia mhdenikwn se  olo to board
        for (int i = 0; i < x; i++) {
            for (int j = 0; j < x; j++) {
                myBoard[i][j] = 0;
            }
        }


        board = new Board(myBoard);
        board.addObserver(view);
        view.drawBoard(board);
        keyPressed = KeyCode.SPACE;
        scene.setOnKeyPressed(event -> {
            keyPressed = event.getCode();
            try {
                if (!board.isGameOver()) {
                    handleModel();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }
    //controller
    private void handleModel() throws IOException {
        Platform.runLater(() -> {
            switch (keyPressed) {
                case UP:
                    board.handleSwipeUp();
                    break;
                case DOWN:
                    board.handleSwipeDown();
                    break;
                case LEFT:
                    board.handleSwipeLeft();
                    break;
                case RIGHT:
                    board.handleSwipeRight();
                    break;
                default:
                    break;

            }
            //print kinhseis sto terminal

            if (x==4){
                System.out.println(Arrays.deepToString(board.getBoard()));
                System.out.println(Arrays.toString(board.getBoard()[0]));
                System.out.println(Arrays.toString(board.getBoard()[1]));
                System.out.println(Arrays.toString(board.getBoard()[2]));
                System.out.println(Arrays.toString(board.getBoard()[3]));
            }
            if(x==3){
                System.out.println(Arrays.deepToString(board.getBoard()));
                System.out.println(Arrays.toString(board.getBoard()[0]));
                System.out.println(Arrays.toString(board.getBoard()[1]));
                System.out.println(Arrays.toString(board.getBoard()[2]));
            }
            if(x==5){
                System.out.println(Arrays.deepToString(board.getBoard()));
                System.out.println(Arrays.toString(board.getBoard()[0]));
                System.out.println(Arrays.toString(board.getBoard()[1]));
                System.out.println(Arrays.toString(board.getBoard()[2]));
                System.out.println(Arrays.toString(board.getBoard()[3]));
                System.out.println(Arrays.toString(board.getBoard()[4]));
            }

            keyPressed = KeyCode.SPACE;     //ksanadikse kinhsh
        });
    }
}