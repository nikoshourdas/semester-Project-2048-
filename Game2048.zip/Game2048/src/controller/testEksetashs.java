package controller;

import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;

public class testEksetashs {

    Scene examScene;

    Button pressthis ;

    Label label = new Label("");
    TextField textField = new TextField();
    GridPane grid ;
    testEksetashs(){
        pressthis = new Button("press me ");
        pressthis.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                label.setText(textField.getText());
            }
        });
        grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setVgap(10);

        grid.add(label,0,1);
        grid.add(textField,0,2);
        grid.add(pressthis,0,3);

        examScene = new Scene(grid,200,200);
    }

    public void setTextField(TextField textField) {
        this.textField = textField;
    }

    public Scene getExamScene() {
        return examScene;
    }
}
