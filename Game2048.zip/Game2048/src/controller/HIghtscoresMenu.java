package controller;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;

//creates a window and displays the top ten scores in ascending order
//loaded from the data base

public class HIghtscoresMenu {

    Scene hsMenu;
    String[] scores = new String[10]; 
    Label hsLabel;
    Label score1,score2,score3,score4,score5,score6,score7,score8,score9,score10;

    public Button goBack ;


    GridPane gridPane ;
    public HIghtscoresMenu(){
        score1 = new Label("1   :   ---");
        score2 = new Label("2   :   ---");
        score3 = new Label("3   :   ---");
        score4 = new Label("4   :   ---");
        score5 = new Label("5   :   ---");
        score6 = new Label("6   :   ---");
        score7 = new Label("7   :   ---");
        score8 = new Label("8   :   ---");
        score9 = new Label("9   :   ---");
        score10 = new Label("10  :   ---");
        goBack = new Button("Go Back");
        goBack.setStyle("-fx-text-fill: #5F9EA0  ");
        goBack.setPrefSize(200,30);
        gridPane = new GridPane();
        hsLabel = new Label("Top 10 Players : \n ");

        hsMenu = new Scene(gridPane,500,500);
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setVgap(5);
        hsLabel.setFont(Font.font("Arial Black", 35));   
        gridPane.add(hsLabel,0,0);

        //attempts a connection to the database if it fails , it catches an sql error . the game still runs
        //without an established connection on the data base

        SingletonDatabase sql=SingletonDatabase.getInstance();  
        try {
            scores=sql.getData();
        } catch (SQLException ex) {
            Logger.getLogger(HIghtscoresMenu.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(HIghtscoresMenu.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(HIghtscoresMenu.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(HIghtscoresMenu.class.getName()).log(Level.SEVERE, null, ex);
        }

        //displays the loaded database array

        score1.setText(scores[0]);
        score2.setText(scores[1]);
        score3.setText(scores[2]);
        score4.setText(scores[3]);
        score5.setText(scores[4]);
        score6.setText(scores[5]);
        score7.setText(scores[6]);
        score8.setText(scores[7]);
        score9.setText(scores[8]);
        score10.setText(scores[9]);
        
        //adds the highscores loaded from the data base

        gridPane.add(score1,0,1);
        gridPane.add(score2,0,2);
        gridPane.add(score3,0,3);
        gridPane.add(score4,0,4);
        gridPane.add(score5,0,5);
        gridPane.add(score6,0,6);
        gridPane.add(score7,0,7);
        gridPane.add(score8,0,8);
        gridPane.add(score9,0,9);
        gridPane.add(score10,0,10);
        gridPane.add(goBack,0,11);

    }

    public Scene getHsMenu() {
        return hsMenu;
    }
}
